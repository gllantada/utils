export const SET_USER = "SET_USER";
export const SET_TOKEN = "SET_TOKEN";
