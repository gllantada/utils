import React from "react"
import { CircularProgress } from '@material-ui/core';


export default function () {
  return <div className="spinner"><CircularProgress /></div>
}