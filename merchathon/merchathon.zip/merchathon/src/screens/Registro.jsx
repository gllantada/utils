import React from 'react'

function Registro() {
  return (
    <div>

    </div>
  )
}

export default Registro
