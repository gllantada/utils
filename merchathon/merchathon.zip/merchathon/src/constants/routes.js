export const SELLER_SCREEN = "/pedidos"
export const SELLER_REPARTOS_SCREEN = "/repartos"
export const LOGIN = "/login"
export const AGREGAR_COLABORADOR = "/agregar_colaborador"
export const COLABORATOR_SCREEN = "/mis-pedidos"
export const HOST = "http://35.232.174.11:8080";
export const ORDER_DETAIL = "/pedido";