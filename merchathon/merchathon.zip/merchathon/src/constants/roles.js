export const SELLER = "SELLER";
export const COLABORATOR = "COLABORATOR";